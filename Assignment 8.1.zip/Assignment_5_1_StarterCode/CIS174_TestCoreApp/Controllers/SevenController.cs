﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using CIS174_TestCoreApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace CIS174_TestCoreApp.Controllers
{
    public class SevenController : Controller
    {
        // GET: Seven
        public IActionResult Index()
        {
            var model = new SevenViewModel();
            model.SelectedValue = "Please select a country";
            
            return View(model);
        }


        // POST: Seven/Create
        [HttpPost]
        public IActionResult Index(SevenViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            return RedirectToAction("Index", "Seven");
        }

    }
}