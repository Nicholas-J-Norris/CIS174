﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CIS174_TestCoreApp.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CIS174_TestCoreApp.Web_API_controllers
{
    [Route("api/house")]
    public class EightController : Controller
    {
        IEnumerable<HouseViewModel> Houses = new List<HouseViewModel>
        {
            new HouseViewModel{Bedrooms = 4, SquareFeet = 1854, DateBuilt = new DateTime(1973,5,28), Flooring = "Carpet"},
            new HouseViewModel{Bedrooms = 3, SquareFeet = 1675, DateBuilt = new DateTime(2015,10,17), Flooring = "Hardwood"}
        };
        // GET: api/house
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(Houses);
        }

        // GET api/house/{id}
        [HttpGet("/{id}")]
        public IActionResult Get([FromRoute]int id)
        {
            int index = id - 1; //turns the id into a index for the list
            if(index < Houses.Count()) //makes sure it is within range
            {
                HouseViewModel h = Houses.ElementAt(index);
            return Ok(h); //returns
            };
            return NotFound();
        }

        // POST api/house/create
        [HttpPost("/create")]
        public IActionResult Post(HouseViewModel model)
        {
            Houses.Append(model);
            string message = "House was added";
            return Created(message, model);
        }
    }
}
